﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace RegisterProject
{
    class DataAccessTest
    {
        [Test]
        public void GetUserPasswordTestUser()
        {
            DataAccess DataAccessDB = new DataAccess();
            string pass = "ABCDEF";
            string user = "Test";
            Assert.AreEqual(pass, DataAccessDB.GetPassword(user));
        }

        [Test]
        public void GetUserPasswordTest2User()
        {
            DataAccess DataAccessDB = new DataAccess();
            string pass = "GHIJKL";
            string user = "Test2";
            Assert.AreEqual(pass, DataAccessDB.GetPassword(user));
        }

        [Test]
        public void GetFirstNameTestUser()
        {
            DataAccess DataAccessDB = new DataAccess();
            string username = "Test";
            string firstName = "TestName";
            Assert.AreEqual(firstName, DataAccessDB.GetFirstName(username));
        }

        [Test]
        public void GetFirstNameTest2User()
        {
            DataAccess DataAccessDB = new DataAccess();
            string username = "Test2";
            string firstName = "Test2Name";
            Assert.AreEqual(firstName, DataAccessDB.GetFirstName(username));
        }

        [Test]
        public void GetAttendanceJohnSmith()
        {
            DataAccess DataAccessDB = new DataAccess();
            int StudentID = 1;
            int Period = 1;
            string SessionDate = "06-01-2021";
            string Attendance = "Present";
            Assert.AreEqual(Attendance,DataAccessDB.GetAttendance(StudentID,Period,SessionDate));
        }

        [Test]
        public void GetAttendanceGerryJames()
        {
            DataAccess DataAccessDB = new DataAccess();
            int StudentID = 6;
            int Period = 1;
            string SessionDate = "06-01-2021";
            string Attendance = "Absent";
            Assert.AreEqual(Attendance, DataAccessDB.GetAttendance(StudentID, Period, SessionDate));
        }

        [Test]
        public void GetPeriodTimeDetailsPeriod1()
        {
            DataAccess DataAccessDB = new DataAccess();
            int Period = 1;            
            string PeriodTime = "07:30";
            Assert.AreEqual(PeriodTime, DataAccessDB.GetPeriodTimeDetails(Period));
        }

        [Test]
        public void GetPeriodTimeDetailsPeriod2()
        {
            DataAccess DataAccessDB = new DataAccess();
            int Period = 2;
            string PeriodTime = "08:30";
            Assert.AreEqual(PeriodTime, DataAccessDB.GetPeriodTimeDetails(Period));
        }

        [Test]
        public void sessionStatusCheck1()
        {
            DataAccess DataAccessDB = new DataAccess();
            int Period = 1;
            string SessionDate = "06-01-2021";
            string Status = "True";
            Assert.AreEqual(Status, DataAccessDB.sessionStatus(Period,SessionDate));
        }

        [Test]
        public void sessionStatusCheck2()
        {
            DataAccess DataAccessDB = new DataAccess();
            int Period = 1;
            string SessionDate = "06-02-2021";
            string Status = "False";
            Assert.AreEqual(Status, DataAccessDB.sessionStatus(Period, SessionDate));
        }

        [Test]
        public void GetAttendanceDaysJohnSmithPresent()
        {
            DataAccess DataAccessDB = new DataAccess();            
            string SessionDate = "06-01-2021";
            string SessionEndDate = "06-02-2021";
            string Attendance = "Present";
            int StudentID = 1;
            int days = 5;
            Assert.AreEqual(days, DataAccessDB.GetAttendanceDays(SessionDate, SessionEndDate,StudentID,Attendance));
        }

        [Test]
        public void GetAttendanceDaysJohnSmithAbsent()
        {
            DataAccess DataAccessDB = new DataAccess();
            string SessionDate = "06-01-2021";
            string SessionEndDate = "06-02-2021";
            string Attendance = "Absent";
            int StudentID = 1;
            int days = 1;
            Assert.AreEqual(days, DataAccessDB.GetAttendanceDays(SessionDate, SessionEndDate, StudentID, Attendance));
        }

        [Test]
        public void GetAttendanceDaysWendyHill()
        {
            DataAccess DataAccessDB = new DataAccess();
            string SessionDate = "06-01-2021";
            string SessionEndDate = "06-02-2021";
            string Attendance = "Present";
            int StudentID = 10;
            int days = 1;
            Assert.AreEqual(days, DataAccessDB.GetAttendanceDays(SessionDate, SessionEndDate, StudentID, Attendance));
        }

    }
}
