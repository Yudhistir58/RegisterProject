﻿
namespace RegisterProject
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackButton = new System.Windows.Forms.Button();
            this.TextFileButton = new System.Windows.Forms.Button();
            this.CsvFileButton = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.DailyButton = new System.Windows.Forms.RadioButton();
            this.TermButton = new System.Windows.Forms.RadioButton();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(116, 365);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(121, 23);
            this.BackButton.TabIndex = 11;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // TextFileButton
            // 
            this.TextFileButton.Location = new System.Drawing.Point(538, 185);
            this.TextFileButton.Name = "TextFileButton";
            this.TextFileButton.Size = new System.Drawing.Size(121, 23);
            this.TextFileButton.TabIndex = 12;
            this.TextFileButton.Text = "Generate Text File";
            this.TextFileButton.UseVisualStyleBackColor = true;
            this.TextFileButton.Click += new System.EventHandler(this.TextFileButton_Click);
            // 
            // CsvFileButton
            // 
            this.CsvFileButton.Location = new System.Drawing.Point(538, 121);
            this.CsvFileButton.Name = "CsvFileButton";
            this.CsvFileButton.Size = new System.Drawing.Size(121, 23);
            this.CsvFileButton.TabIndex = 13;
            this.CsvFileButton.Text = "Generate CSV File";
            this.CsvFileButton.UseVisualStyleBackColor = true;
            this.CsvFileButton.Click += new System.EventHandler(this.CsvFileButton_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(116, 121);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(208, 20);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // DailyButton
            // 
            this.DailyButton.AutoSize = true;
            this.DailyButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DailyButton.Location = new System.Drawing.Point(538, 245);
            this.DailyButton.Name = "DailyButton";
            this.DailyButton.Size = new System.Drawing.Size(114, 24);
            this.DailyButton.TabIndex = 17;
            this.DailyButton.TabStop = true;
            this.DailyButton.Text = "Daily Report";
            this.DailyButton.UseVisualStyleBackColor = true;
            this.DailyButton.Click += new System.EventHandler(this.DailyButton_Click);
            // 
            // TermButton
            // 
            this.TermButton.AutoSize = true;
            this.TermButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TermButton.Location = new System.Drawing.Point(538, 306);
            this.TermButton.Name = "TermButton";
            this.TermButton.Size = new System.Drawing.Size(116, 24);
            this.TermButton.TabIndex = 18;
            this.TermButton.TabStop = true;
            this.TermButton.Text = "Term Report";
            this.TermButton.UseVisualStyleBackColor = true;
            this.TermButton.Click += new System.EventHandler(this.TermButton_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(116, 185);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(208, 20);
            this.dateTimePicker2.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(112, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "End Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(112, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "Start Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(339, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 37);
            this.label6.TabIndex = 27;
            this.label6.Text = "Report";
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.TermButton);
            this.Controls.Add(this.DailyButton);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.CsvFileButton);
            this.Controls.Add(this.TextFileButton);
            this.Controls.Add(this.BackButton);
            this.Name = "ReportForm";
            this.Text = "Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button TextFileButton;
        private System.Windows.Forms.Button CsvFileButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RadioButton DailyButton;
        private System.Windows.Forms.RadioButton TermButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
    }
}