﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegisterProject
{
    public partial class MenuForm : Form
    {
        public string username;
        DataAccess DataAccessDB = new DataAccess();
        public MenuForm()
        {
            InitializeComponent();
        }

        public MenuForm(string Username)
        {
            InitializeComponent();            
            var LoginForm = new LoginForm();
            username = Username;
            WelcomeLabel.Text = "Welcome " + DataAccessDB.GetFirstName(username);
        }

        private void LogAttendanceButton_Click(object sender, EventArgs e)
        {                        
            this.Hide();
            var Attendance = new AttendanceForm(username);
            Attendance.Show();            

        }

        private void StudentAdminButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var StudentAdmin = new StudentAdminForm(username);
            StudentAdmin.Show();
        }
    }
}
