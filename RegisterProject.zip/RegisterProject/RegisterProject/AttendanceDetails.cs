﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegisterProject
{
    public class AttendanceDetails
    {
        public int StudentID;
        public string Period;
        public string SessionDate;
        public string Attendance;
        public string Grade;
        public string ClassName;

    }
}
