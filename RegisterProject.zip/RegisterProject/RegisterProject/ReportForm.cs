﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegisterProject
{
    public partial class ReportForm : Form
    {
        private string username;
        private string grade;
        private string className;
        private string sessionDate;
        private string sessionEndDate;
        private string format;

        public ReportForm()
        {
            InitializeComponent();
        }

        public ReportForm(string Username, string Grade, string ClassName)
        {
            InitializeComponent();
            username = Username;
            grade = Grade;
            className = ClassName;
            dateTimePicker2.Hide();
            label1.Hide();
            DailyButton.Checked = true;
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MM-dd-yyyy";
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "MM-dd-yyyy";
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Attendance = new AttendanceForm(username,grade,className);
            Attendance.Show();
        }

        private void CsvFileButton_Click(object sender, EventArgs e)
        {
            format = "csv";
            GenerateReport();
        }

        private void TextFileButton_Click(object sender, EventArgs e)
        {
            format = "txt";
            GenerateReport();
        }

        private void GenerateReport()
        {
            if (DailyButton.Checked)
            {
                sessionDate = dateTimePicker1.Value.ToString("MM-dd-yyyy");
                Report ReportObj = new Report();
                string result = ReportObj.GenerateReport(sessionDate, format);
                MessageBox.Show("Report Generated", "Daily Report", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (TermButton.Checked)
            {
                sessionDate = dateTimePicker1.Value.ToString("MM-dd-yyyy");
                sessionEndDate = dateTimePicker2.Value.ToString("MM-dd-yyyy");
                if (Convert.ToDateTime(sessionEndDate) > Convert.ToDateTime(sessionDate))
                {
                    Report ReportObj = new Report();
                    string result = ReportObj.GenerateReport(sessionDate,sessionEndDate,format);
                    MessageBox.Show("Report Generated", "Term Report", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Please ensure end date is greater than start date", "Term Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DailyButton_Click(object sender, EventArgs e)
        {
            dateTimePicker2.Hide();
            label1.Hide();
        }

        private void TermButton_Click(object sender, EventArgs e)
        {
            dateTimePicker2.Show();
            label1.Show();
        }

    }
}
