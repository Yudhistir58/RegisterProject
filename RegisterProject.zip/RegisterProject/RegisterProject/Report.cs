﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegisterProject
{
    class Report
    {
        DataAccess DataAccessDB = new DataAccess();
        public string GenerateReport(string sessionDate, string format)
        {
            var dailyReport = DataAccessDB.GetDailyReportDetails(sessionDate);
            dailyReport.ToList();
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using (StreamWriter StreamWriterObj = new StreamWriter(Path.Combine(docPath, sessionDate+"."+format)))
            {                
                StreamWriterObj.WriteLine("Daily Report for: " +sessionDate);
                StreamWriterObj.WriteLine("Period,Period Time,First Name,Last Name, Attendance");
                foreach (DailyReport s in dailyReport)
                    StreamWriterObj.WriteLine(s.Period+","+s.PeriodTime+","+s.FirstName + "," + s.LastName+ "," + s.Attendance);
            }
                return "Yes";
        }

        public string GenerateReport(string sessionDate, string sessionEndDate, string format)
        {
            var termReport = DataAccessDB.GetTermReportDetails(sessionDate,sessionEndDate);
            termReport.ToList();
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using (StreamWriter StreamWriterObj = new StreamWriter(Path.Combine(docPath, sessionDate+" to "+sessionEndDate+ "." + format)))
            {
                StreamWriterObj.WriteLine("Term Report from: " +sessionDate+ " to "+sessionEndDate);
                StreamWriterObj.WriteLine("FirstName,LastName,Grade,ClassName,Classes Attended, Classes Missed");
                foreach (TermReport s in termReport)
                {
                    StreamWriterObj.WriteLine(s.FirstName + "," + s.LastName + "," + s.Grade + "," + s.ClassName +","+ DataAccessDB.GetAttendanceDays(sessionDate, sessionEndDate, s.studentID,"Present") + "," + DataAccessDB.GetAttendanceDays(sessionDate, sessionEndDate, s.studentID, "Absent"));
                }
            }
            return "Yes";
        }
    }
}
