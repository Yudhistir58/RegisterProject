﻿
namespace RegisterProject
{
    partial class AttendanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StudentList = new System.Windows.Forms.ListBox();
            this.GradeBox = new System.Windows.Forms.ComboBox();
            this.ClassNameBox = new System.Windows.Forms.ComboBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.PresentButton = new System.Windows.Forms.RadioButton();
            this.AbsentButton = new System.Windows.Forms.RadioButton();
            this.PeriodBox = new System.Windows.Forms.ComboBox();
            this.PeriodTimeBox = new System.Windows.Forms.TextBox();
            this.SessionDateBox = new System.Windows.Forms.TextBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.ReportButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // StudentList
            // 
            this.StudentList.FormattingEnabled = true;
            this.StudentList.Location = new System.Drawing.Point(47, 129);
            this.StudentList.Name = "StudentList";
            this.StudentList.Size = new System.Drawing.Size(127, 173);
            this.StudentList.TabIndex = 0;
            this.StudentList.Click += new System.EventHandler(this.StudentList_Click);
            // 
            // GradeBox
            // 
            this.GradeBox.FormattingEnabled = true;
            this.GradeBox.Location = new System.Drawing.Point(219, 131);
            this.GradeBox.Name = "GradeBox";
            this.GradeBox.Size = new System.Drawing.Size(121, 21);
            this.GradeBox.TabIndex = 1;
            this.GradeBox.SelectedIndexChanged += new System.EventHandler(this.GradeBox_SelectedIndexChanged);
            // 
            // ClassNameBox
            // 
            this.ClassNameBox.FormattingEnabled = true;
            this.ClassNameBox.Location = new System.Drawing.Point(402, 131);
            this.ClassNameBox.Name = "ClassNameBox";
            this.ClassNameBox.Size = new System.Drawing.Size(121, 21);
            this.ClassNameBox.TabIndex = 2;
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(596, 129);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(121, 23);
            this.SearchButton.TabIndex = 3;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // PresentButton
            // 
            this.PresentButton.AutoSize = true;
            this.PresentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PresentButton.Location = new System.Drawing.Point(243, 276);
            this.PresentButton.Name = "PresentButton";
            this.PresentButton.Size = new System.Drawing.Size(82, 24);
            this.PresentButton.TabIndex = 4;
            this.PresentButton.TabStop = true;
            this.PresentButton.Text = "Present";
            this.PresentButton.UseVisualStyleBackColor = true;
            this.PresentButton.Click += new System.EventHandler(this.PresentButton_Click);
            // 
            // AbsentButton
            // 
            this.AbsentButton.AutoSize = true;
            this.AbsentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AbsentButton.Location = new System.Drawing.Point(423, 276);
            this.AbsentButton.Name = "AbsentButton";
            this.AbsentButton.Size = new System.Drawing.Size(78, 24);
            this.AbsentButton.TabIndex = 5;
            this.AbsentButton.TabStop = true;
            this.AbsentButton.Text = "Absent";
            this.AbsentButton.UseVisualStyleBackColor = true;
            this.AbsentButton.Click += new System.EventHandler(this.AbsentButton_Click);
            // 
            // PeriodBox
            // 
            this.PeriodBox.FormattingEnabled = true;
            this.PeriodBox.Location = new System.Drawing.Point(219, 220);
            this.PeriodBox.Name = "PeriodBox";
            this.PeriodBox.Size = new System.Drawing.Size(121, 21);
            this.PeriodBox.TabIndex = 7;
            this.PeriodBox.SelectedIndexChanged += new System.EventHandler(this.PeriodBox_SelectedIndexChanged);
            // 
            // PeriodTimeBox
            // 
            this.PeriodTimeBox.Location = new System.Drawing.Point(402, 220);
            this.PeriodTimeBox.Name = "PeriodTimeBox";
            this.PeriodTimeBox.ReadOnly = true;
            this.PeriodTimeBox.Size = new System.Drawing.Size(121, 20);
            this.PeriodTimeBox.TabIndex = 8;
            // 
            // SessionDateBox
            // 
            this.SessionDateBox.Location = new System.Drawing.Point(596, 219);
            this.SessionDateBox.Name = "SessionDateBox";
            this.SessionDateBox.ReadOnly = true;
            this.SessionDateBox.Size = new System.Drawing.Size(121, 20);
            this.SessionDateBox.TabIndex = 9;
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(219, 334);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(121, 23);
            this.BackButton.TabIndex = 10;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ReportButton
            // 
            this.ReportButton.Location = new System.Drawing.Point(596, 334);
            this.ReportButton.Name = "ReportButton";
            this.ReportButton.Size = new System.Drawing.Size(121, 23);
            this.ReportButton.TabIndex = 11;
            this.ReportButton.Text = "Create Report";
            this.ReportButton.UseVisualStyleBackColor = true;
            this.ReportButton.Click += new System.EventHandler(this.DailyReportButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Student List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(252, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Grade";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(443, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Class";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(252, 197);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Period";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(419, 198);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Period Time";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(634, 198);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(275, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(179, 37);
            this.label7.TabIndex = 27;
            this.label7.Text = "Attendance";
            // 
            // AttendanceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ReportButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.SessionDateBox);
            this.Controls.Add(this.PeriodTimeBox);
            this.Controls.Add(this.PeriodBox);
            this.Controls.Add(this.AbsentButton);
            this.Controls.Add(this.PresentButton);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.ClassNameBox);
            this.Controls.Add(this.GradeBox);
            this.Controls.Add(this.StudentList);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Name = "AttendanceForm";
            this.Text = "AttendanceForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox StudentList;
        private System.Windows.Forms.ComboBox GradeBox;
        private System.Windows.Forms.ComboBox ClassNameBox;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.RadioButton PresentButton;
        private System.Windows.Forms.RadioButton AbsentButton;
        private System.Windows.Forms.ComboBox PeriodBox;
        private System.Windows.Forms.TextBox PeriodTimeBox;
        private System.Windows.Forms.TextBox SessionDateBox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ReportButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}