﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegisterProject
{
    public partial class StudentAdminForm : Form
    {
        private List<String> DataLog = new List<string>();
        private string username;
        DataAccess DataAccessDB = new DataAccess();
        public StudentAdminForm()
        {
            InitializeComponent();            
        }

        public StudentAdminForm(string Username)
        {
            InitializeComponent();
            username = Username;
            EditLogList.DataSource = GetDataLog();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            
            if ((String.IsNullOrEmpty(FirstNameBox.Text)) || (String.IsNullOrEmpty(LastNameBox.Text)) || (String.IsNullOrEmpty(GradeBox.Text)) || (String.IsNullOrEmpty(ClassNameBox.Text)))
            {
                MessageBox.Show("Please enter all fields", "Add Student",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DataAccessDB.CreateStudent(FirstNameBox.Text, LastNameBox.Text, GradeBox.Text, ClassNameBox.Text);
                DataLog.Add(FirstNameBox.Text+" "+LastNameBox.Text+" Added");
                EditLogList.DataSource = GetDataLog();
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Menu = new MenuForm(username);
            Menu.Show();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string records = String.Empty;
            if ((String.IsNullOrEmpty(FirstNameBox.Text)) || (String.IsNullOrEmpty(LastNameBox.Text)) || (String.IsNullOrEmpty(GradeBox.Text)) || (String.IsNullOrEmpty(ClassNameBox.Text)))
            {
                MessageBox.Show("Please enter all fields", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                records = DataAccessDB.DeleteStudent(FirstNameBox.Text, LastNameBox.Text, GradeBox.Text, ClassNameBox.Text);
                
                if (Convert.ToInt32(records) > 0)
                {
                    DataLog.Add(FirstNameBox.Text + " " + LastNameBox.Text + " Deleted");
                    EditLogList.DataSource = GetDataLog();
                }
                else
                {
                    MessageBox.Show("No record to delete", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private List<string> GetDataLog()
        {
            return DataLog.ToList();
        }

    }
}
