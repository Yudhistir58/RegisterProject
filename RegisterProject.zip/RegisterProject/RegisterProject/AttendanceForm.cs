﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegisterProject
{
    public partial class AttendanceForm : Form
    {
        private List<string> StudentIDList;
        private List<string> StudentNameList;
        private string username;
        private string sessionDateVar;
        DataAccess DataAccessDB = new DataAccess();
        public AttendanceForm()
        {
            InitializeComponent();
        }

        public AttendanceForm(string Username)
        {
            InitializeComponent();
            username = Username;       
            GradeBox.DataSource = DataAccessDB.GetGradeDetails();
            ClassNameBox.DataSource = DataAccessDB.GetClassNameDetails(GradeBox.Text);
            PeriodBox.DataSource = DataAccessDB.GetPeriodDetails();
            PeriodTimeBox.Text = DataAccessDB.GetPeriodTimeDetails(Convert.ToInt32(PeriodBox.Text));
            SessionDateBox.Text = DateTime.Today.ToString("MM-dd-yyyy");
            sessionDateVar = SessionDateBox.Text;
        }

        public AttendanceForm(string Username, string Grade, string ClassName)
        {
            InitializeComponent();
            username = Username;            
            GradeBox.DataSource = DataAccessDB.GetGradeDetails();
            GradeBox.SelectedItem = Grade;
            ClassNameBox.DataSource = DataAccessDB.GetClassNameDetails(GradeBox.Text);
            ClassNameBox.SelectedItem = ClassName;
            PeriodBox.DataSource = DataAccessDB.GetPeriodDetails();
            PeriodTimeBox.Text = DataAccessDB.GetPeriodTimeDetails(Convert.ToInt32(PeriodBox.Text));
            SessionDateBox.Text = DateTime.Today.ToString("MM-dd-yyyy");
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            StudentNameList = DataAccessDB.GetStudentNames(GradeBox.Text, ClassNameBox.Text);
            StudentList.DataSource = StudentNameList;
            StudentIDList = DataAccessDB.GetStudentID(GradeBox.Text, ClassNameBox.Text);
        }

        private void StudentList_Click(object sender, EventArgs e)
        {
            PresentButton.Checked = false;
            AbsentButton.Checked = false;
            if (StudentList.SelectedIndex >= 0)
            {
                string attendance = DataAccessDB.GetAttendance(Convert.ToInt32(StudentIDList[StudentList.SelectedIndex]), Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text);
                if (attendance == "Present")
            {
                    PresentButton.Checked = true;
                }
            else if (attendance == "Absent")
                {
                    AbsentButton.Checked = true;
                }
            }
        }

        private void GradeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClassNameBox.DataSource = DataAccessDB.GetClassNameDetails(GradeBox.Text);            
        }
        private void PresentButton_Click(object sender, EventArgs e)
        {
            string error = String.Empty;
            string attendance = DataAccessDB.GetAttendance(Convert.ToInt32(StudentIDList[StudentList.SelectedIndex]), Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text);
            if (attendance == "Absent")
            {
                DataAccessDB.SetAttendance(Convert.ToInt32(StudentIDList[StudentList.SelectedIndex]), Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text, "Present");
            }
            else if ( string.IsNullOrEmpty(attendance))
            {
                if (DataAccessDB.sessionStatus(Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text) == "False")
                {
                    DataAccessDB.CreateSession(Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text,username);
                }
                DataAccessDB.CreateAttendance(Convert.ToInt32(StudentIDList[StudentList.SelectedIndex]), Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text, "Present");
            }
        }

        private void PeriodBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            PeriodTimeBox.Text = DataAccessDB.GetPeriodTimeDetails(Convert.ToInt32(PeriodBox.Text));
            PresentButton.Checked = false;
            AbsentButton.Checked = false;
        }

        private void AbsentButton_Click(object sender, EventArgs e)
        {
            string attendance = DataAccessDB.GetAttendance(Convert.ToInt32(StudentIDList[StudentList.SelectedIndex]), Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text);
            if (attendance == "Present")
            {
                DataAccessDB.SetAttendance(Convert.ToInt32(StudentIDList[StudentList.SelectedIndex]), Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text, "Absent");
            }
            else if (string.IsNullOrEmpty(attendance))
            {
                if (DataAccessDB.sessionStatus(Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text) == "False")
                {                    
                    DataAccessDB.CreateSession(Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text, username);

                }
                DataAccessDB.CreateAttendance(Convert.ToInt32(StudentIDList[StudentList.SelectedIndex]), Convert.ToInt32(PeriodBox.Text), SessionDateBox.Text, "Absent");                
            }
        }
        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Menu = new MenuForm(username);
            Menu.Show();
        }

        private void DailyReportButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Report = new ReportForm(username, GradeBox.Text, ClassNameBox.Text);
            Report.Show();
        }

    }
}
