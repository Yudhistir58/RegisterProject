﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegisterProject
{
    public class DailyReport
    {
        public string Period;
        public string PeriodTime;
        public string FirstName;
        public string LastName;
        public string Attendance;
    }
}
