﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegisterProject
{
    public partial class LoginForm : Form
    {

        DataAccess DataObject = new DataAccess();
        public LoginForm()
        {
            InitializeComponent();                        
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string user = UserBox.Text;
            if ((DataObject.GetPassword(user) == PasswordBox.Text)&&(!String.IsNullOrEmpty(DataObject.GetPassword(user))))
            {
                this.Hide();
                var Menu = new MenuForm(user);
                Menu.Show();
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
