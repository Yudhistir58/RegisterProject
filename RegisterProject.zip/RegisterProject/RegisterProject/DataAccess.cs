﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegisterProject
{
    class DataAccess
    {
    
        public string GetPassword(string Username)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var name = cnn.Query<string>("Select PasswordHash from TeacherDetails where TeacherID = '"+Username+"'", new DynamicParameters());
                name.ToList();
                if (name.Any())
                {
                    return name.First();
                }
                else
                {
                    return String.Empty;
                }
            }
        }

        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }

        public string GetFirstName(string Username)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var name = cnn.Query<string>("Select FirstName from TeacherDetails where TeacherID = '" + Username + "'", new DynamicParameters());
                name.ToList();
                if (name.Any())
                {
                    return name.First();
                }
                else
                {
                    return String.Empty;
                }
            }
        }

        public List<string> GetStudentNames(string grade, string className)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var studentNames = cnn.Query<string>("Select FirstName||' '||LastName from StudentDetails where grade = '"+grade+"' and className = '"+className+"' order by StudentID", new DynamicParameters());
                return studentNames.ToList();
            }
        }

        public List<string> GetStudentID(string grade, string className)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var studentID = cnn.Query<string>("Select StudentID from StudentDetails where grade = '" + grade + "' and className = '" + className + "' order by StudentID", new DynamicParameters());
                return studentID.ToList();
            }
        }

        public List<string> GetGradeDetails()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var gradeDetails = cnn.Query<string>("Select Distinct Grade from StudentDetails", new DynamicParameters());
                return gradeDetails.ToList();
            }
        }

        public List<string> GetClassNameDetails(string grade)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                if (grade == null)
                {
                    var classNameDetails = cnn.Query<string>("Select Distinct ClassName from StudentDetails", new DynamicParameters());
                    return classNameDetails.ToList();
                }
                else
                {
                    var classNameDetails = cnn.Query<string>("Select Distinct ClassName from StudentDetails where grade = '" + grade + "'", new DynamicParameters());
                    return classNameDetails.ToList();
                }
            }
        }

        public string GetAttendance(int studentID, int period, string sessionDate)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var attendance = cnn.Query<string>("Select Attendance from SessionDetails,AttendanceDetails where StudentID = '" + studentID + "' and AttendanceDetails.Period = '" + period+"' and AttendanceDetails.SessionDate = '"+sessionDate+"'", new DynamicParameters());
                attendance.ToList();
                if (attendance.Any())
                {
                    return attendance.First();
                }
                else
                {
                    return String.Empty;
                }
            }
        }

        public string SetAttendance(int studentID, int period, string sessionDate, string attendance)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                try
                {
                    cnn.Execute("Update AttendanceDetails set Attendance = @Attendance where Period = @Period AND SessionDate = @SessionDate AND StudentID = @StudentID;", new { Period = period, SessionDate = sessionDate, StudentID = studentID, Attendance = attendance });
                    return "Update Complete";
                }
                catch (Exception e)
                {
                    return e.ToString();
                }
            }
        }

        public string CreateAttendance(int studentID, int period, string sessionDate, string attendance)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                try
                {                    
                    cnn.Execute("Insert into AttendanceDetails (Period,SessionDate,StudentID,Attendance) values (@Period,@SessionDate,@StudentID,@Attendance);", new {  Period = period, SessionDate = sessionDate, StudentID = studentID, Attendance = attendance });
                    return "Insert Complete";
                }
                catch (Exception e)
                {
                    return e.ToString();
                }
            }
        }

        public string CreateSession( int period, string sessionDate, string username)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                try
                {
                    cnn.Execute("Insert into SessionDetails (Period,SessionDate,TeacherID) values (@Period,@SessionDate,@Username);", new { Period = period, SessionDate = sessionDate, Username = username });
                    return "Insert Complete";
                }
                catch (Exception e)
                {
                    return e.ToString();
                }
            }
        }

        public List<string> GetPeriodDetails()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var periodDetails = cnn.Query<string>("Select Distinct Period from PeriodDetails order by Period", new DynamicParameters());
                return periodDetails.ToList();
            }
        }

        public string GetPeriodTimeDetails(int period)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var periodTimeDetails = cnn.Query<string>("Select PeriodTime from PeriodDetails where Period = '" + period + "'", new DynamicParameters());
                periodTimeDetails.ToList();
                return periodTimeDetails.First();
            }
        }

        public string sessionStatus(int period, string sessionDate)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var sessionDetails = cnn.Query<string>("Select 'True' from SessionDetails where Period = '" + period + "' and SessionDate = '"+sessionDate+"'", new DynamicParameters());
                sessionDetails.ToList();
                if (sessionDetails.Any())
                {
                    return sessionDetails.First();
                }
                else
                {
                    return "False";
                }
            }
        }
        public void CreateStudent(string firstName, string lastName, string grade, string className)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                try
                {
                    cnn.Execute("Insert into StudentDetails (FirstName,LastName,Grade,ClassName) values (@FirstName,@LastName,@Grade,@ClassName);", new { FirstName = firstName, LastName = lastName, Grade = grade, ClassName = className });
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }
        public string DeleteStudent(string firstName, string lastName, string grade, string className)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                try
                {
                    return cnn.Execute("Delete from StudentDetails where FirstName = @FirstName and LastName = @LastName and Grade = @Grade and ClassName = @ClassName;", new { FirstName = firstName, LastName = lastName, Grade = grade, ClassName = className }).ToString();
                    
                }
                catch (Exception e)
                {
                    return e.ToString();
                }
            }
        }

        public List<DailyReport> GetDailyReportDetails(string sessionDate)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var dailyReportDetails = cnn.Query<DailyReport>("Select a.Period, b.PeriodTime, FirstName, LastName, Attendance from AttendanceDetails a, PeriodDetails b, StudentDetails c where a.Period = b.Period  and a.StudentID = c.StudentID and SessionDate = '"+sessionDate+"' order by a.Period", new DynamicParameters());
                return dailyReportDetails.ToList();
            }
        }

        public List<TermReport> GetTermReportDetails(string sessionStartDate, string sessionEndDate)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var dailyReportDetails = cnn.Query<TermReport>("Select FirstName,LastName,Grade,ClassName,StudentID from StudentDetails order by Grade,ClassName,LastName,FirstName", new DynamicParameters());
                return dailyReportDetails.ToList();
            }
        }

        public int GetAttendanceDays(string sessionDate, string sessionEndDate, int studentID, string attendance)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                int count = 0;
                Console.WriteLine(studentID);
                var sessionDetails = cnn.Query<AttendanceDetails>("Select * from AttendanceDetails where StudentID = '" + studentID + "' and Attendance = '"+attendance+"'", new DynamicParameters());
                sessionDetails.ToList();
                foreach (AttendanceDetails s in sessionDetails)
                {
                    Console.WriteLine(s.SessionDate+" "+Convert.ToDateTime(s.SessionDate));
                    if ((Convert.ToDateTime(s.SessionDate) >= Convert.ToDateTime(sessionDate)) && (Convert.ToDateTime(s.SessionDate) <= Convert.ToDateTime(sessionEndDate)))
                    {
                        count++;
                    }
                }
                return count;
            }
        }
    }


}
